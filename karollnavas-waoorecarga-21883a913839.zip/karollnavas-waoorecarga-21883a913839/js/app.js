'use strict';
var waoo = (function () {
  var waooserver = 'http://waoo.herokuapp.com',
    $visuales, $loginForm, $rechargingForm, $username, $operador;

  function init() {
    $visuales = $('.js-login, .js-recharging, .js-session-frame');
    $loginForm = $('.js-login-form');
    $rechargingForm = $('.js-recharging-form');
    $username = $('.js-username');
    $operador = $('.js-operador');
    document.querySelector('.js-logout').onclick = logout;
    document.querySelector('.js-login-button').onclick = login;
    document.querySelector('.js-recharging-button').onclick = recargar;
  }

  function login() {
    var usuario = document.querySelector('.js-usuario').value;
    if(usuario!=''){
      var clave = document.querySelector('.js-clave').value;
      clave = md5(clave);
      var ajx = $.ajax({
        type: 'post',
        url: waooserver+'/sesiones/loginOperador',
        dataType: 'json',
        data: {nickname:usuario,clave:clave}
      });
      ajx.done(function(resp) {
        if(resp.msg == 'ok'){
          $visuales.toggleClass('hidden');
          $loginForm[0].reset();
          $username.html(usuario);
          $operador.val(usuario);
        }
        else alert(resp.msg);
      })
      .fail(function(e) {
        alert('Error: ' + e.message);
      });
    }
    else {
      alert('Ingrese un nombre de usuario');
    }
  }

  function logout(e) {
    e.preventDefault();
    $visuales.toggleClass('hidden');
    $username.html('');
    $operador.val('')
  }

  function recargar() {
    var usuario = document.querySelector('.js-nick').value;
    var valor = document.querySelector('.js-valor').value * 1;
    if(usuario=='' || valor==0){
      alert('Complete todos los datos');
    }
    else{
      var ajx = $.ajax({
        type: 'post',
        url: waooserver+'/usuarios/recargaTokensOperador',
        dataType: 'json',
        data: $rechargingForm.serialize()
      });
      ajx.done(function(resp) {
        if(resp.msg == 'ok'){
          alert(resp.msg);
          $rechargingForm[0].reset();
        }
        else alert(resp.msg);
      })
      .fail(function(e) {
        alert('Error: ' + e.message);
      });
    }
  }

  return{
    init: init
  }
})();
document.addEventListener('DOMContentLoaded', function(e) {
  waoo.init();
});
